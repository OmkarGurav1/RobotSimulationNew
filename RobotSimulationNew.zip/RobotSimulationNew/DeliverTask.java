package com.robosimulation.task;

import com.robosimulation.behaviours.TaskBehaviour;

public class DeliverTask implements TaskBehaviour {

    @Override
    public void executeTask() {
        System.out.println("Robot is delivering");
    }
}