package com.robosimulation.behaviours;

public interface TaskBehaviour {
    public void executeTask();
}