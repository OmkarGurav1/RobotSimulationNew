package com.robosimulation.behaviours;

public interface MovementBehaviour {
    public void move();
}