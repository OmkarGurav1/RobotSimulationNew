package com.robosimulation.context;

import com.robosimulation.behaviours.MovementBehaviour;
import com.robosimulation.behaviours.TaskBehaviour;

public class Robot {
    private String name;

    private MovementBehaviour movementBehaviour;

    private TaskBehaviour taskBehaviour;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setMovementBehaviour(MovementBehaviour movementBehaviour) {
        this.movementBehaviour = movementBehaviour;
    }

    public MovementBehaviour getMovementBehaviour() {
        return movementBehaviour;
    }

    public void setTaskBehaviour(TaskBehaviour taskBehaviour) {
        this.taskBehaviour = taskBehaviour;
    }

    public TaskBehaviour getTaskBehaviour() {
        return taskBehaviour;
    }

    public void performTask() {
        taskBehaviour.executeTask();
    }

    public void performMove() {
        movementBehaviour.move();
    }
}