package com.robosimulation.movement;

import com.robosimulation.behaviours.MovementBehaviour;

public class FlyBehaviour implements MovementBehaviour {

    @Override
    public void move() {
        System.out.println("Robot is flying");
    }
}