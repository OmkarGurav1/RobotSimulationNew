package com.robosimulation.test;

import com.robosimulation.context.Robot;
import com.robosimulation.behaviours.*;
import com.robosimulation.movement.*;
import com.robosimulation.task.*;

public class Test {
    public static void main(String[] args) {
        Robot robot1 = new Robot();
        robot1.setName("Walker Robot");

        MovementBehaviour walk = new WalkBehaviour();
        TaskBehaviour clean = new CleanTask();

        robot1.setMovementBehaviour(walk);
        robot1.setTaskBehaviour(clean);

        MovementBehaviour fly = new FlyBehaviour();
        robot1.setMovementBehaviour(fly);

        TaskBehaviour fight = new FightTask();
        robot1.setTaskBehaviour(fight);

        MovementBehaviour roll = new RollBehaviour();
        robot1.setMovementBehaviour(roll);

        TaskBehaviour weld = new WeldTask();
        robot1.setTaskBehaviour(weld);

        TaskBehaviour deliver = new DeliverTask();
        robot1.setTaskBehaviour(deliver);

        robot1.performMove();
        robot1.performTask();
    }
}