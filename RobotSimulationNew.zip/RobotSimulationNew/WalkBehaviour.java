package com.robosimulation.movement;

import com.robosimulation.behaviours.MovementBehaviour;

public class WalkBehaviour implements MovementBehaviour {

    @Override
    public void move() {
        System.out.println("Robot is walking");
    }
}