package com.robosimulation.task;

import com.robosimulation.behaviours.TaskBehaviour;

public class WeldTask implements TaskBehaviour {

    @Override
    public void executeTask() {
        System.out.println("Robot is welding");
    }
}