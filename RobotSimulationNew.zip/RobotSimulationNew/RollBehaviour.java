package com.robosimulation.movement;

import com.robosimulation.behaviours.MovementBehaviour;

public class RollBehaviour implements MovementBehaviour {

    @Override
    public void move() {
        System.out.println("Robot is rolling");
    }
}