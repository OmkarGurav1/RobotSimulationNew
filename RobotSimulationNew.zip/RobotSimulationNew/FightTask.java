package com.robosimulation.task;

import com.robosimulation.behaviours.TaskBehaviour;

public class FightTask implements TaskBehaviour {

    @Override
    public void executeTask() {
        System.out.println("Robot is fighting");
    }
}